# Core module - Shared infrastructure and utilities
