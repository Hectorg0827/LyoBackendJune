"""Monetization package: ad schemas and selection engine."""
