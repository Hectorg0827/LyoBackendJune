"""
Providers module initialization
"""
