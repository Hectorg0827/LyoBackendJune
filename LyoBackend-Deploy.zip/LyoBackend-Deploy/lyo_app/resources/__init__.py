"""
Educational Resources Module
Aggregates free educational content from multiple APIs
"""
